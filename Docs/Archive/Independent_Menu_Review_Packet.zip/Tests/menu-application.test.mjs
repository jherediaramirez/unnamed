import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const script = fs.readFileSync(new URL('../Scripts/MenuApplicationRuntime.js', import.meta.url), 'utf8');
function fixture({canQuit=true, reject=false, saveFailure=false}={}) {
  const calls=[], notices=[], button={disabled:true};
  let requested=false;
  const context=vm.createContext({
    window:{ue:{menuapp:{
      getstate:async()=>JSON.stringify({ok:!requested||!saveFailure,canQuit,pendingQuit:false,
        quitIssued:requested&&!saveFailure,error:requested&&saveFailure?'Settings could not be saved.':''}),
      requestquit:async()=>{calls.push('quit');requested=!reject;return JSON.stringify({
        ok:!reject,canQuit,pendingQuit:!reject&&saveFailure,quitIssued:!reject&&!saveFailure,
        error:reject?'Standalone only.':''});}
    }}},
    screen:{querySelectorAll:()=>[button]},clone:structuredClone,
    MenuVideo:{prepareForExit:async()=>{calls.push('drain');await new Promise(resolve=>setTimeout(resolve,5));calls.push('saved');},cancelExit:()=>calls.push('unlock')},
    message:(...args)=>notices.push(args),console,Date,setTimeout,setInterval(){},
  });
  vm.runInContext(script,context);
  return {api:context.window.MenuApplication,calls,notices,button};
}
test('quit drains settings once and prevents repeated submissions',async()=>{
  const f=fixture();await f.api.initialize();
  const closing=f.api.quit();await f.api.quit();await closing;
  assert.deepEqual(f.calls,['drain','saved','quit']);
  assert.equal(f.button.disabled,true);
  assert.equal(f.notices.length,0);
});
test('editor quit remains disabled and never reaches native shutdown',async()=>{
  const f=fixture({canQuit:false});await f.api.initialize();await f.api.quit();
  assert.equal(f.button.disabled,true);
  assert.equal(f.calls.length,0);
});
test('native rejection unlocks settings and reports the failure',async()=>{
  const f=fixture({reject:true});await f.api.initialize();await f.api.quit();
  assert.deepEqual(f.calls,['drain','saved','quit','unlock']);
  assert.equal(f.notices[0][1],'Standalone only.');
  assert.equal(f.button.disabled,false);
});
test('failed final save cancels quit and keeps the interface recoverable',async()=>{
  const f=fixture({saveFailure:true});await f.api.initialize();await f.api.quit();
  assert.equal(f.calls.at(-1),'unlock');
  assert.equal(f.notices[0][1],'Settings could not be saved.');
  assert.equal(f.button.disabled,false);
});
