const liveVideoSettings = new Set(['fullscreen', 'framerateLimit', 'enableVsync', 'guiScale', 'menuBackgroundBlurriness']);
const MenuVideo = (() => {
  let bridge = null, snapshot = null, running = null, polling = false, resetting = false, exitLocked = false;
  const pending = new Map();
  const cloneState = () => snapshot ? clone(snapshot) : null;
  const method = name => bridge[name.toLowerCase()] || bridge[name];
  const call = async (name, ...args) => {
    const fn = method(name);
    if (typeof fn !== 'function') throw Error('Video settings connection is unavailable.');
    const reply = await fn.apply(bridge, args);
    const value = typeof reply === 'string' ? JSON.parse(reply) : reply;
    if (!value || typeof value.ok !== 'boolean' || !value.settings || !value.capabilities || !value.observed)
      throw Error('Invalid response from the video settings service.');
    return value;
  };
  function absorb(value) {
    snapshot = value;
    const oldScale = state.settings.guiScale;
    for (const id of liveVideoSettings) {
      if (pending.has(id) || (id === 'fullscreen' && value.pendingFullscreen)) continue;
      state.settings[id] = value.settings[id];
    }
    applyAppearance();
    if (oldScale !== state.settings.guiScale) resize();
    refreshSettings();
  }
  function report(error) {
    console.warn('Video settings: ' + error);
    message('Video Settings', String(error));
  }
  async function waitForWindow(value) {
    const deadline = Date.now() + 7000;
    while (value.pendingFullscreen) {
      if (Date.now() > deadline) throw Error('The game window did not finish changing mode.');
      await new Promise(resolve => setTimeout(resolve, 100));
      value = await call('GetState');
      absorb(value);
    }
    return value;
  }
  async function drain() {
    while (pending.size) {
      const [id, value] = pending.entries().next().value;
      pending.delete(id);
      try {
        let reply = await call('ApplySetting', id, JSON.stringify({value}));
        // A later edit remains visible while this asynchronous response is in flight.
        if (!pending.has(id)) state.settings[id] = value;
        absorb(reply);
        reply = await waitForWindow(reply);
        absorb(reply);
        if (!reply.ok || reply.error) report(reply.error || 'The setting could not be applied.');
      } catch (error) {
        pending.delete(id);
        try { absorb(await call('GetState')); } catch {}
        report(error.message);
      }
    }
  }
  function startDrain() {
    if (running) return running;
    running = drain().finally(() => { running = null; if (pending.size) startDrain(); });
    return running;
  }
  function set(id, value) {
    const d = D[id];
    const valid = !d ? false : id === 'guiScale' ? Number.isInteger(value) && value >= 0 && value <= maximumScale() : d.values ? d.values.includes(value) : Number.isFinite(value) &&
      value >= d.min && value <= (id === 'guiScale' ? maximumScale() : d.max) &&
      Number.isInteger((value - d.min) / d.step);
    if (!liveVideoSettings.has(id) || !valid) throw Error('Invalid video setting ' + id);
    if (resetting || exitLocked || !snapshot?.capabilities[id]) return Promise.resolve();
    state.settings[id] = value;
    if (quality.has(id)) state.settings.graphicsPreset = 'Custom';
    if (id === 'guiScale') resize();
    else { applyAppearance(); refreshSettings(); }
    pending.set(id, value);
    return startDrain();
  }
  async function initialize() {
    for (let attempt = 0; attempt < 100; attempt++) {
      bridge = window.ue?.menuvideo;
      if (bridge) break;
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    if (!bridge) {
      console.warn('Native video settings unavailable; live controls remain disabled.');
      return;
    }
    try { absorb(await waitForWindow(await call('GetState'))); }
    catch (error) { report(error.message); }
  }
  async function hardReset() {
    if (resetting || exitLocked || !snapshot?.capabilities.fullscreen) return;
    resetting = true;
    refreshSettings();
    try {
      while (running || pending.size) await (running || startDrain());
      let reply = await call('HardReset');
      reply = await waitForWindow(reply);
      absorb(reply);
      if (!reply.ok || reply.error) throw Error(reply.error || 'Settings could not be reset.');
      // Reload recreates every mock preference/draft from the original first-run defaults.
      window.location.reload();
    } catch (error) { resetting = false; refreshSettings(); report(error.message); }
  }
  setInterval(async () => {
    if (!bridge || running || polling || resetting) return;
    polling = true;
    try { const reply = await call('GetState'); if (!running) absorb(reply); }
    catch (error) { console.warn('Video settings synchronization: ' + error.message); }
    finally { polling = false; }
  }, 500);
  return {
    set, initialize, hardReset, getState: cloneState,
    enabled: id => !resetting && !exitLocked && !!snapshot?.capabilities[id],
    prepareForExit: async () => {
      exitLocked = true;
      refreshSettings();
      while (running || pending.size) await (running || startDrain());
    },
    cancelExit: () => { exitLocked = false; refreshSettings(); },
    settled: async () => { while (running || pending.size) await (running || startDrain()); return cloneState(); }
  };
})();
window.MenuVideo = MenuVideo;
void MenuVideo.initialize();
