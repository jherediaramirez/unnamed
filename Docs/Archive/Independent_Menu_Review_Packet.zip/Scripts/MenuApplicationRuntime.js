const MenuApplication = (() => {
  let bridge = null, snapshot = null, quitting = false, polling = false;
  const enabled = () => !quitting && !!snapshot?.canQuit && !snapshot.pendingQuit && !snapshot.quitIssued;
  function refresh() {
    for (const button of screen.querySelectorAll('[data-application-quit]')) button.disabled = !enabled();
  }
  async function call(name) {
    const method = bridge[name.toLowerCase()] || bridge[name];
    if (typeof method !== 'function') throw Error('Game shutdown is unavailable.');
    const result = await method.call(bridge);
    const reply = typeof result === 'string' ? JSON.parse(result) : result;
    if (!reply || typeof reply.ok !== 'boolean' || typeof reply.canQuit !== 'boolean' ||
        typeof reply.pendingQuit !== 'boolean' || typeof reply.quitIssued !== 'boolean')
      throw Error('Invalid response from the game shutdown service.');
    snapshot = reply;
    refresh();
    return reply;
  }
  async function quit() {
    if (!enabled()) return;
    quitting = true;
    refresh();
    try {
      await MenuVideo.prepareForExit();
      let reply = await call('RequestQuit');
      if (!reply.ok) throw Error(reply.error || 'The game could not close.');
      const deadline = Date.now() + 10000;
      while (!reply.quitIssued) {
        if (Date.now() > deadline) throw Error('The game did not finish closing. Please try again.');
        await new Promise(resolve => setTimeout(resolve, 100));
        reply = await call('GetState');
        if (!reply.ok) throw Error(reply.error || 'The game could not close.');
      }
      // Keep changes locked until Unreal completes its normal shutdown.
    } catch (error) {
      quitting = false;
      MenuVideo.cancelExit();
      refresh();
      message('Quit Game', error.message);
    }
  }
  async function initialize() {
    for (let attempt = 0; attempt < 100; attempt++) {
      bridge = window.ue?.menuapp;
      if (bridge) break;
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    if (!bridge) return;
    try { await call('GetState'); }
    catch (error) { console.warn('Game shutdown: ' + error.message); }
  }
  setInterval(async () => {
    if (!bridge || quitting || polling) return;
    polling = true;
    try { await call('GetState'); }
    catch (error) { console.warn('Game shutdown synchronization: ' + error.message); }
    finally { polling = false; }
  }, 500);
  return {enabled, quit, initialize, getState: () => snapshot ? clone(snapshot) : null};
})();
window.MenuApplication = MenuApplication;
void MenuApplication.initialize();
